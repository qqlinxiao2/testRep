<li>
  <div class="excerpt-num">
  	<span class="num-comm num-comm-hot"><strong><?php  echo $article->CommNums;  ?></strong>answers</span> 
    <span class="num-view"><strong><?php  echo $article->ViewNums;  ?></strong>views</span> 
  </div>
  <h2 class="excerpt-tit"> <a href="<?php  echo $article->Url;  ?>"><?php  echo $article->Title;  ?></a> </h2>
  <p class="excerpt-desc"> <?php $intro= preg_replace('/[\r\n\s]+/', '', trim(SubStrUTF8(TransferHTML($article->Intro,'[nohtml]'),80)).'...'); ?><?php  echo $intro;  ?> </p>
  <div class="excerpt-tag"> <?php  foreach ( $article->Tags as $tag) { ?><a href="<?php  echo $tag->Url;  ?>"><?php  echo $tag->Name;  ?></a><?php }   ?> </div>
  <div class="excerpt-time"><?php  echo $article->Time('Y年m月d日');  ?></div>
</li>