<li style="padding-left:0;">
  <h2 class="excerpt-tit"> <a href="<?php  echo $article->Url;  ?>">[置顶]<?php  echo $article->Title;  ?></a> </h2>
  <p class="excerpt-desc"> <?php $intro= preg_replace('/[\r\n\s]+/', '', trim(SubStrUTF8(TransferHTML($article->Intro,'[nohtml]'),80)).'...'); ?><?php  echo $intro;  ?> </p>
  <div class="excerpt-time"><?php  echo $article->Time('Y年m月d日');  ?></div>
</li>