<?php  include $this->GetTemplate('header');  ?>
<?php if ($DFiveAD1ON) { ?><div class="banner"><?php  echo $DFiveAD1;  ?></div><?php } ?>
<?php if ($DFiveTipsON) { ?><div class="thetip"><?php  echo $DFiveTips;  ?></div><?php } ?>
<div class="share-txt share-home">我喜欢，分享到：<a class="dshare ds_tqq">腾讯微博</a><a class="dshare ds_qzone">QQ空间</a><a class="dshare ds_tsina">新浪微博</a><a class="dshare ds_renren">人人网</a><a class="dshare ds_kaixin">开心网</a><a class="dshare ds_douban">豆瓣</a><a class="dshare ds_facebook">Facebook</a><a class="dshare ds_twitter">Twitter</a></div>
<?php if ($type!='index') { ?>
<h2 class="base-tit queryinfo"><?php  echo $title;  ?>的内容</h2>
<?php } ?>
<ul class="excerpt<?php if ($DFiveThumb) { ?> thumb<?php } ?>">
<?php  foreach ( $articles as $article) { ?>
    <?php if ($article->IsTop) { ?>
    	<?php  include $this->GetTemplate('post-istop');  ?>
    <?php }else{  ?>
    	<?php if ($DFiveThumb) { ?>
        	<?php  include $this->GetTemplate('post-thumb');  ?>
        <?php }else{  ?>
    		<?php  include $this->GetTemplate('post-multi');  ?>
        <?php } ?>
    <?php } ?>
<?php }   ?>
</ul>
<div class="paging"><?php  include $this->GetTemplate('pagebar');  ?></div>
</div>
<?php  include $this->GetTemplate('post-sidebar');  ?>
<?php  include $this->GetTemplate('footer');  ?>