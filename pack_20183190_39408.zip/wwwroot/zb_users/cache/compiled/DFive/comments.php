<?php if ($socialcomment) { ?>
<?php  echo $socialcomment;  ?>
<?php }else{  ?>
<div id="postcomments">
<?php if ($article->CommNums>0) { ?>
<h3 class="base-tit" id="comments"> <span><a href="#"></a></span><strong><?php  echo $article->CommNums;  ?></strong>访客评论，博主回复<strong>4</strong>条 </h3>
<?php } ?>
<label id="AjaxCommentBegin"></label>
<!--评论输出-->
<ol class="commentlist">
<?php  foreach ( $comments as $key => $comment) { ?>
<?php  include $this->GetTemplate('comment');  ?>
<?php }   ?>
</ol>
<!--评论翻页条输出-->
<div class="pagenav pagebar commentpagebar">
<?php  include $this->GetTemplate('pagebar');  ?>
</div>
<label id="AjaxCommentEnd"></label>
</div>
<!--评论框-->
<?php  include $this->GetTemplate('commentpost');  ?>
<?php } ?>