<div class="meta">
  <h1 class="meta-tit"><?php  echo $article->Title;  ?></h1>
</div>
<?php if ($DFiveAD2ON) { ?><div class="banner"><?php  echo $DFiveAD2;  ?></div><?php } ?>
<div class="entry"> <?php  echo $article->Content;  ?> </div>
<div class="share-txt">分享到：<a class="dshare ds_tqq">腾讯微博</a><a class="dshare ds_qzone">QQ空间</a><a class="dshare ds_tsina">新浪微博</a><a class="dshare ds_renren">人人网</a><a class="dshare ds_kaixin">开心网</a><a class="dshare ds_douban">豆瓣</a><a class="dshare ds_facebook">Facebook</a><a class="dshare ds_twitter">Twitter</a></div>
<?php if ($DFiveAD3ON) { ?><div class="banner"><?php  echo $DFiveAD3;  ?></div><?php } ?>
<?php if (!$article->IsLock) { ?>
<?php  include $this->GetTemplate('comments');  ?>
<?php } ?> 