<div class="sidebar">
	<ul class="mypages">
		<li><a target="_blank" class="my-a my-tqq" href="http://"><span><strong>腾讯微博</strong></span>腾讯微博 &raquo;</a></li>
		<li><a target="_blank" class="my-a my-weibo" href="http://"><span><strong>新浪微博</strong></span>新浪微博 &raquo;</a></li>
	</ul>
    <?php  include $this->GetTemplate('sidebar');  ?>
</div>