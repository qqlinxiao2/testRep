<div class="widget" id="<?php  echo $module->HtmlID;  ?>">
    <?php if ((!$module->IsHideTitle)&&($module->Name)) { ?>
    <h3 class="widget-tit"><?php  echo $module->Name;  ?></h3>
    <?php }else{  ?>
    <h3 style="display:"><?php  echo $module->Name;  ?></h3>
    <?php } ?>
    <?php if ($module->Type=='div') { ?>
    <div><?php  echo $module->Content;  ?></div>
    <?php } ?>
    <?php if ($module->Type=='ul') { ?>
    <ul>
      <?php  echo $module->Content;  ?>
    </ul>
    <?php } ?>
</div>
