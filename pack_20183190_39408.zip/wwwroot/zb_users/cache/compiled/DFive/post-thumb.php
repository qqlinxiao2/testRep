<li> <a href="<?php  echo $article->Url;  ?>" class="pic"><img src="<?php  echo DFive_thumbs($article->Content);  ?>" alt="<?php  echo $article->Title;  ?>" /></a>
  <h2 class="excerpt-tit"> <a href="<?php  echo $article->Url;  ?>"><?php  echo $article->Title;  ?></a> </h2>
  <p class="excerpt-desc"> <?php $intro= preg_replace('/[\r\n\s]+/', '', trim(SubStrUTF8(TransferHTML($article->Intro,'[nohtml]'),80)).'...'); ?><?php  echo $intro;  ?> </p>
  <div class="excerpt-tag"> <?php  foreach ( $article->Tags as $tag) { ?><a href="<?php  echo $tag->Url;  ?>"><?php  echo $tag->Name;  ?></a><?php }   ?> <span><?php  echo $article->CommNums;  ?>评论 &nbsp; <?php  echo $article->ViewNums;  ?>次访问</span> </div>
  <div class="excerpt-time"><?php  echo $article->Time('Y年m月d日');  ?></div>
</li>