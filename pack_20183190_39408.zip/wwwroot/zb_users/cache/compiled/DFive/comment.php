<label id="cmt<?php  echo $comment->ID;  ?>"></label><li class="comment byuser comment-author-admin bypostauthor even thread-even depth-1" id="comment-<?php  echo $comment->ID;  ?>">
  <div class="c-floor"><a href="#comment-<?php  echo $comment->ID;  ?>">#<?php  echo $comment->FloorID;  ?></a></div>
  <div class="c-avatar"><img src="<?php  echo $comment->Author->Avatar;  ?>" class="avatar" /></div>
  <div class="c-main" id="div-comment-<?php  echo $comment->ID;  ?>">
    <p><?php  echo $comment->Content;  ?></p>
    <div class="c-meta"><span class="c-author"><a href="<?php  echo $comment->Author->HomePage;  ?>" target="_blank" rel="external nofollow" class="url"><?php  echo $comment->Author->StaticName;  ?></a></span><?php  echo $comment->Time();  ?><a href="#respond"  class='comment-reply-link' onclick="RevertComment('<?php  echo $comment->ID;  ?>')">回复该评论</a></div>
  </div>
</li>
<?php  foreach ( $comment->Comments as $comment) { ?>
<div style="padding-left:20px"><?php  include $this->GetTemplate('comment');  ?></div>
<?php }   ?>