<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width" />
<title><?php if ($type=='index') { ?><?php  echo $name;  ?>_<?php  echo $title;  ?>
<?php }elseif($type=='category') {  ?><?php  echo $title;  ?>_<?php  echo $name;  ?>
<?php }elseif($type=='article') {  ?><?php  echo $title;  ?>_<?php  echo $article->Category->Name;  ?>_<?php  echo $name;  ?>
<?php }else{  ?><?php  echo $title;  ?>_<?php  echo $name;  ?><?php } ?></title>
<?php  echo $header;  ?>
<meta name="generator" content="<?php  echo $zblogphp;  ?>" />
<link rel="stylesheet" rev="stylesheet" href="<?php  echo $host;  ?>zb_users/theme/<?php  echo $theme;  ?>/style/<?php  echo $style;  ?>.css" type="text/css" media="all"/>
<script src="<?php  echo $host;  ?>zb_system/script/common.js" type="text/javascript"></script>
<script src="<?php  echo $host;  ?>zb_system/script/c_html_js_add.php" type="text/javascript"></script>
<script src="<?php  echo $host;  ?>zb_users/theme/<?php  echo $theme;  ?>/script/common.js"></script>
<?php  echo $header;  ?>
<?php if ($type=='index'&&$page=='1') { ?>
	<link rel="alternate" type="application/rss+xml" href="<?php  echo $feedurl;  ?>" title="<?php  echo $name;  ?>" />
	<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php  echo $host;  ?>zb_system/xml-rpc/?rsd" />
	<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php  echo $host;  ?>zb_system/xml-rpc/wlwmanifest.xml" />
<?php } ?>
</head>
<body class="multi <?php  echo $type;  ?>">
<div class="topbar">
	<div class="inner">
		<h1 class="logo"><a class="logo" href="<?php  echo $host;  ?>" title="<?php  echo $name;  ?> - <?php  echo $subname;  ?>"><?php  echo $subname;  ?></a></h1>
		<ul class="nav">
			<?php  if(isset($modules['navbar'])){echo $modules['navbar']->Content;}  ?>
		</ul>
		<form name="search" method="post" action="<?php  echo $host;  ?>zb_system/cmd.php?act=search" class="search-form">
			<input type="text" x-webkit-speech onfocus="if (this.value == '回车搜索 直接有效') {this.value = '';}" onblur="if (this.value == '') {this.value = '回车搜索 直接有效';}" value="回车搜索 直接有效" name="q" class="search-input" />
		</form>
		<ul class="nav topmenu">
			<?php  if(isset($modules['favorite'])){echo $modules['favorite']->Content;}  ?>
		</ul>
	</div>
</div>
<div class="wrapper">
	<div class="content">