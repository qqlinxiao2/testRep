<ul class="page-menu">
	<?php if ($pagebar) { ?>
		<?php  foreach ( $pagebar->buttons as $k=>$v) { ?>
		    <?php if ($pagebar->PageNow==$k) { ?>
		    <li><span class="page-now"></span><a>　</a></li>
		    <?php }elseif($k=='‹‹') {  ?>
		    <a href="<?php  echo $v;  ?>" class="page-left">　</a>
		    <?php }elseif($k=='››') {  ?>
		    <a href="<?php  echo $v;  ?>" class="page-right">　</a>
		    <?php }elseif($k=='‹') {  ?>
		    
		    <?php }elseif($k=='›') {  ?>
		    
		    <?php }else{  ?>
		    <li><a href="<?php  echo $v;  ?>"><?php  echo $k;  ?></a></li>
		    <?php } ?>
		<?php }   ?>
	<?php } ?>
</ul>