<div class="comm-post" id="divCommentPost">
	<div class="comment comment-form" id="comment">
		<form id="frmSumbit" target="_self" method="post" action="<?php  echo $article->CommentPostUrl;  ?>" >
			<input type="hidden" name="inpId" id="inpId" value="<?php  echo $article->ID;  ?>" />
			<input type="hidden" name="inpRevID" id="inpRevID" value="0" />
			<?php if ($user->ID>0) { ?>
				<input type="hidden" name="inpName" id="inpName" value="<?php  echo $user->Name;  ?>" />
				<input type="hidden" name="inpEmail" id="inpEmail" value="<?php  echo $user->Email;  ?>" />
				<input type="hidden" name="inpHomePage" id="inpHomePage" value="<?php  echo $user->HomePage;  ?>" />
			<?php }else{  ?>
				<input type="text" name="inpName" id="inpName" value="<?php  echo $user->Name;  ?>" />
				<input type="text" name="inpEmail" id="inpEmail" value="<?php  echo $user->Email;  ?>" />
				<input type="text" name="inpHomePage" id="inpHomePage" value="<?php  echo $user->HomePage;  ?>" />
			<?php } ?>
			<div class="text">
				<textarea type="text" name="txaArticle" id="txaArticle" class="textarea" ></textarea>
			</div>
			<div class="code">
				<?php if ($option['ZC_COMMENT_VERIFY_ENABLE']) { ?>
					<input type="text" class="ipt" name="inpVerify" id="inpVerify"  value="" />
					
					<img style="width:<?php  echo $option['ZC_VERIFYCODE_WIDTH'];  ?>px;height:<?php  echo $option['ZC_VERIFYCODE_HEIGHT'];  ?>px;cursor:pointer;" src="<?php  echo $article->ValidCodeUrl;  ?>" alt="" title="" onclick="javascript:this.src='<?php  echo $article->ValidCodeUrl;  ?>&amp;tm='+Math.random();"/>
				<?php } ?>
			</div>
			<div class="menu">
				<input name="sumbit" type="submit" tabindex="6" onclick="return VerifyMessage()" value="发表评论" class="post-submit"/>
			</div>
		</form>
	</div>
</div>