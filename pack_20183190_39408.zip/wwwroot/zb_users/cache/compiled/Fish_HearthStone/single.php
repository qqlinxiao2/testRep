
	<?php  include $this->GetTemplate('header');  ?>
						
						<div class="g-con">
							<div class="m-con-widh">
								<?php if ($article->Type==ZC_POST_TYPE_ARTICLE) { ?>
									<?php  include $this->GetTemplate('post-single');  ?>
								<?php }else{  ?>
									<?php  include $this->GetTemplate('post-page');  ?>
								<?php } ?>
								
							</div>
							<div class="m-con-widh-foot"></div>
						</div><!-- ./g-con -->
					
			<?php  include $this->GetTemplate('footer');  ?>
			
		
		
		