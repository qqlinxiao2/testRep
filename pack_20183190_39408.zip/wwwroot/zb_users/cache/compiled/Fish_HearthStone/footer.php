</div><!-- ./g-main -->
				</div>
			</div>
<div class="g-foot">
				<div class="m-foot">
					<?php  echo $copyright;  ?>
				</div>
			</div>
			</div>
			<?php  echo $footer;  ?>
	</body>
</html>