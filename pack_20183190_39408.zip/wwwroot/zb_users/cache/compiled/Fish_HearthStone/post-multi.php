<div class="m-blog-list">
	<?php 
		$listimg = $zbp->Config('Fish_HearthStone') -> list_img;
		$firstIMG2=mt_rand(1,4);
		$pattern="/<[img|IMG].*?src=[\'|\"](.*?(?:[\.gif|\.jpg|\.png]))[\'|\"].*?[\/]?>/";
		$content = $article->Content;
		preg_match_all($pattern,$content,$matchContent);
		if(isset($matchContent[1][0]))
			$firstIMG2=$matchContent[1][0];
		else
			$firstIMG2=$zbp->host."zb_users/theme/$theme/style/img/random/$firstIMG2.jpg";
	 ?>
	<div class="<?php  echo $listimg;  ?>">
		<div class="img-border">
			<img src="<?php  echo $firstIMG2;  ?>" />
		</div>
		
	</div>
	<div class="blog-con">
		<h1 class="title"><a href="<?php  echo $article->Url;  ?>"><?php  echo $article->Title;  ?></a></h1>
		<div class="abstract">
			<?php 
	    $intro2= preg_replace('/[\r\n\s]+/', '', trim(SubStrUTF8(TransferHTML($article->Intro,'[nohtml]'),60)).'...');
			 ?>
			<?php  echo $intro2;  ?>
			
		</div>
		<div class="reply"><a href="<?php  echo $article->Url;  ?>"><?php  echo $article->CommNums;  ?></a></div>
		<div class="data"><?php  echo $article->Time('Y-m-d');  ?></div>
	</div>
</div><!-- ./m-blog-list -->
