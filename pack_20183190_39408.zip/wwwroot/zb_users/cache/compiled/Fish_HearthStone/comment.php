<label id="cmt<?php  echo $comment->ID;  ?>"></label><div class="comm-list" name="cmt<?php  echo $comment->ID;  ?>">
	<ul>
		<li>
			<a href="#comment" class="list-back" onclick="RevertComment('<?php  echo $comment->ID;  ?>')">回复该评论</a>
			<div class="list-sub">
				<a href="<?php  echo $comment->Author->HomePage;  ?>" class="name"><?php  echo $comment->Author->StaticName;  ?></a>
				<span># <?php  echo $comment->FloorID;  ?></span>
				<span class="data"><?php  echo $comment->Time();  ?></span>
			</div>
			<div class="list-con">
				<?php  echo $comment->Content;  ?>
			</div>
		</li>
		<?php  foreach ( $comment->Comments as $comment) { ?>
			<?php  include $this->GetTemplate('c_comment-back');  ?>
		<?php }   ?>
	</ul>
</div>