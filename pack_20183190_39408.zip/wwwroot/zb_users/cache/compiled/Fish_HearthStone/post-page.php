<div class="m-blog-con">
	<h2 class="blog-tt"><?php  echo $article->Title;  ?></h2>
	<div class="blog-sub">
		<span class="name">作者：<?php  echo $article->Author->Name;  ?></span>
		<span class="time"><?php  echo $article->Time('Y-m-d H:i:s');  ?></span>
		<span class="reply"><?php  echo $article->CommNums;  ?></span>
	</div>
	<div class="blogCon">
		<?php  echo $article->Content;  ?>
		
	</div>
</div>
<div class="m-blog-line"></div>
<?php if (!$article->IsLock) { ?>
	<?php  include $this->GetTemplate('comments');  ?>
<?php } ?>
