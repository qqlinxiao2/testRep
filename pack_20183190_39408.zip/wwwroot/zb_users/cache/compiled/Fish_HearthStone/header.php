<!DOCTYPE html>
<html>
<head>
		<meta charset="UTF-8">
		<title><?php  echo $name;  ?>-<?php  echo $title;  ?></title>
		<meta name="generator" content="<?php  echo $zblogphp;  ?>" />
		<link rel="stylesheet" href="<?php  echo $host;  ?>zb_users/theme/<?php  echo $theme;  ?>/style/css/reset.css" />
		<link rel="stylesheet" href="<?php  echo $host;  ?>zb_users/theme/<?php  echo $theme;  ?>/style/style.css" />
		<script src="<?php  echo $host;  ?>zb_system/script/common.js" type="text/javascript"></script>
		<script type="text/javascript" src="<?php  echo $host;  ?>zb_users/theme/<?php  echo $theme;  ?>/script/banner.js" ></script>
		<script src="<?php  echo $host;  ?>zb_system/script/c_html_js_add.php" type="text/javascript"></script>
		<?php  echo $header;  ?>
		
		<?php if ($type=='index'&&$page=='1') { ?>
		
			<link rel="alternate" type="application/rss+xml" href="<?php  echo $feedurl;  ?>" title="<?php  echo $name;  ?>" />
			<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php  echo $host;  ?>zb_system/xml-rpc/?rsd" />
			<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php  echo $host;  ?>zb_system/xml-rpc/wlwmanifest.xml" />
		<?php } ?>
		
	</head>
	<body>
		<div class="g-body">
			<div class="m-body-top-bg">
				<div class="m-body-foot-bg">
					<div class="g-main">
						<?php  include $this->GetTemplate('c_top');  ?>