<div class="m-blog-con">
	<h2 class="blog-tt"><?php  echo $article->Title;  ?></h2>
	<div class="blog-sub">
		<span class="name">作者：<?php  echo $article->Author->Name;  ?></span>
		<span class="time"><?php  echo $article->Time('Y-m-d H:i:s');  ?></span>
		<span class="reply"><?php  echo $article->CommNums;  ?></span>
		<span class="tag">标签：
			<?php  foreach ( $article->Tags as $tag) { ?><a href="<?php  echo $tag->Url;  ?>"><?php  echo $tag->Name;  ?></a><?php }   ?>
		</span>
	</div>
	<div class="blogCon">
		<?php  echo $article->Content;  ?>
		
	</div>
</div>
<div class="m-blog-next">
	<div class="left">上一篇：<a href="<?php  echo $article->Prev->Url;  ?>"><?php  echo $article->Prev->Title;  ?></a></div>
	<div class="right">下一篇：<a href="<?php  echo $article->Next->Url;  ?>"><?php  echo $article->Next->Title;  ?></a></div>
</div>
<div class="m-blog-line"></div>
<?php if (!$article->IsLock) { ?>
	<?php  include $this->GetTemplate('comments');  ?>
<?php } ?>
