<!DOCTYPE html>
<html>
<head>
    <title></title>
    <script type="text/javascript" src="../internal.js"></script>
    <link rel="stylesheet" type="text/css" href="edittable.css">
</head>
<body>
<div class="wrapper">
    <div class="left">
        <div class="section">
            <h3><var id="lang_tableStyle"></var></h3>
            <ul>
                <li>
                    <label onselectstart="return false"><input type="checkbox" id="J_title" name="style"/><var id="lang_insertTitle"></var></label>
                </li>
                <li>
                    <label onselectstart="return false"><input type="checkbox" id="J_titleCol" name="style"/><var id="lang_insertTitleCol"></var></label>
                </li>
            </ul>
            <ul>
                <li>
                    <label onselectstart="return false"><input type="checkbox" id="J_caption" name="style"/><var id="lang_insertCaption"></var></label>
                </li>
                <li>
                    <label onselectstart="return false"><input type="checkbox" id="J_sorttable" name="style"/><var id="lang_orderbycontent"></var></label>
                </li>
            </ul>
            <div class="clear"></div>
        </div>
        <div class="section">
            <h3><var id="lang_tableSize"></var></h3>
            <ul>
                <li>
                    <label><input type="radio" id="J_autoSizeContent" name="size"/><var id="lang_autoSizeContent"></var></label>
                </li>
                <li>
                    <label><input type="radio" id="J_autoSizePage" name="size"/><var id="lang_autoSizePage"></var></label>
                </li>
            </ul>
            <div class="clear"></div>
        </div>
        <div class="section">
            <h3><var id="lang_borderStyle"></var></h3>
            <ul>
                <li>
                    <span><var id="lang_color"></var></span>
                    <input type="text" class="tone" id="J_tone" readonly='readonly' />
                </li>
            </ul>
            <div class="clear"></div>
        </div>
    </div>
    <div class="right">
        <div class="section">
            <h3><var id="lang_example"></var></h3>
            <div class="preview" id="J_preview">
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="edittable.js"></script>
</body>
</html>