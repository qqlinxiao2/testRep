<?php
//注册插件
RegisterPlugin('Fish_HearthStone', 'ActivePlugin_Fish_HearthStone');

//具体的接口挂接
function ActivePlugin_Fish_HearthStone()
{
	Add_Filter_Plugin('Filter_Plugin_Admin_TopMenu', 'Fish_HearthStone_AddMenu');
}

//执行代码
function Fish_HearthStone_AddMenu(&$menus)
{
	global $zbp;
	$menus[] = MakeTopMenu('root', '主题配置', $zbp->host . 'zb_users/theme/Fish_HearthStone/main.php?act=config', '', '');
}

function InstallPlugin_Fish_HearthStone()
{
	global $zbp;
	//配置初始化
	if(!$zbp->Config('Fish_HearthStone')->HasKey('version')){
		$zbp->Config('Fish_HearthStone')->side_tt="关于我们";
		$zbp->Config('Fish_HearthStone')->side_con="想要自己组建一副套牌，然后用它来和其他玩家对战？现在马上就下载《炉石传说》并投入游戏吧，没有什么比参与实战更能让你学到东西的了！ ";
		$zbp->Config('Fish_HearthStone')->side_linktt="新浪微博";
		$zbp->Config('Fish_HearthStone')->side_link="#";
		$zbp->Config('Fish_HearthStone')->side_tt_img="stone";
		$zbp->Config('Fish_HearthStone')->banner_link_01="#";
		$zbp->Config('Fish_HearthStone')->banner_link_02="#";
		$zbp->Config('Fish_HearthStone')->banner_link_03="#";
		$zbp->Config('Fish_HearthStone')->list_img="blogimg";
		$zbp->SaveConfig('Fish_HearthStone');
	}
}

function UninstallPlugin_Fish_HearthStone()
{
	global $zbp;
}

function Fish_HearthStone_SubMenu($id){
	$arySubMenu = array(
		0 => array('右侧栏设置', 'config', 'left', false),
		1 => array('首页BANNER设置', 'banner', 'left', false)
	);
	foreach($arySubMenu as $k => $v){
		echo '<a href="?act='.$v[1].'" '.($v[3]==true?'target="_blank"':'').'><span class="m-'.$v[2].' '.($id==$v[1]?'m-now':'').'">'.$v[0].'</span></a>';
	}
}

function Fish_HearthStone_Require($config_name)
{
	global $blogpath;
	$file_name = explode('/', $config_name);
	include($blogpath . 'zb_users/theme/Fish_HearthStone/include/' . end($file_name));
}

function Fish_HearthStone_Url($config_name)
{
	global $bloghost;
	$file_array = explode('/', $config_name);
	return $bloghost . 'zb_users/theme/Fish_HearthStone/include/' . end($file_array); //safe
}
?>