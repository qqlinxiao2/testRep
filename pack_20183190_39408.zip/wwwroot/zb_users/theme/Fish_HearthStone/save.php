<?php
require '../../../zb_system/function/c_system_base.php';
require '../../../zb_system/function/c_system_admin.php';

$zbp->Load();
$action='root';
if (!$zbp->CheckRights($action)) {$zbp->ShowError(6);die();}
if (!$zbp->CheckPlugin($blogtheme)) {$zbp->ShowError(48);die();}

//右侧设置
if($_GET['type'] == 'side' ){
	global $zbp;
	//获取信息
	$sidett = $_POST["sidett"];
	$sidecon = $_POST["sidecon"];
	$sidelinktt = $_POST["sidelinktt"];
	$sidelink = $_POST["sidelink"];
	$sidettimg = $_POST["sidettimg"];
	$listimg = $_POST["listimg"];
	
	$zbp->Config('Fish_HearthStone')->side_tt = $sidett;
	$zbp->Config('Fish_HearthStone')->side_con = $sidecon;
	$zbp->Config('Fish_HearthStone')->side_linktt = $sidelinktt;
	$zbp->Config('Fish_HearthStone')->side_link = $sidelink;
	$zbp->Config('Fish_HearthStone')->side_tt_img = $sidettimg;
	$zbp->Config('Fish_HearthStone')->list_img = $listimg;
	
	//保存并返回
	$zbp->SaveConfig('Fish_HearthStone');
	$zbp->SetHint('good','修改成功');
	Redirect('./main.php?act=config');
}

//BANNER
if($_GET['type'] == 'banner' ){
	global $zbp;
	//获取信息
	$bannerlink01 = $_POST["bannerlink01"];
	$bannerlink02 = $_POST["bannerlink02"];
	$bannerlink03 = $_POST["bannerlink03"];
	
	$zbp->Config('Fish_HearthStone')->banner_link_01 = $bannerlink01;
	$zbp->Config('Fish_HearthStone')->banner_link_02 = $bannerlink02;
	$zbp->Config('Fish_HearthStone')->banner_link_03 = $bannerlink03;
	$zbp->SaveConfig('Fish_HearthStone');
	
	foreach ($_FILES as $key => $value){
		if(!strpos($key, "_php")){
			if (is_uploaded_file($_FILES[$key]['tmp_name'])){
				$tmp_name = $_FILES[$key]['tmp_name'];
				switch($key){
					case 'banner01': 
						$imgname = "banner01.jpg";
						break;
					case 'banner02': 
						$imgname = "banner02.jpg";
						break;
					case 'banner03': 
						$imgname = "banner03.jpg";
						break;
				}
				@move_uploaded_file($_FILES[$key]['tmp_name'], $zbp->usersdir . 'theme/Fish_HearthStone/include/' . $imgname);
			}
		}
	}
	
	//保存并返回
	$zbp->SetHint('good','修改成功');
	Redirect('./main.php?act=banner');
}
?>