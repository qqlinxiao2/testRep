<?php
require '../../../zb_system/function/c_system_base.php';
require '../../../zb_system/function/c_system_admin.php';

$zbp->Load();
$action='root';
if (!$zbp->CheckRights($action)) {$zbp->ShowError(6);die();}
if (!$zbp->CheckPlugin($blogtheme)) {$zbp->ShowError(48);die();}

$blogtitle = "配置页面";
$act = "";
if ($_GET['act']){
	$act = $_GET['act'] == "" ? 'base' : $_GET['act'];
}

$sidett = $zbp->Config('Fish_HearthStone') -> side_tt;
$sidecon = $zbp->Config('Fish_HearthStone') -> side_con;
$sidelinktt = $zbp->Config('Fish_HearthStone') -> side_linktt;
$sidelink = $zbp->Config('Fish_HearthStone') -> side_link;
$sidettimg = $zbp->Config('Fish_HearthStone') -> side_tt_img;
$bannerlink_01 = $zbp->Config('Fish_HearthStone') -> banner_link_01;
$bannerlink_02 = $zbp->Config('Fish_HearthStone') -> banner_link_02;
$bannerlink_03 = $zbp->Config('Fish_HearthStone') -> banner_link_03;
$listimg = $zbp->Config('Fish_HearthStone') -> list_img;

$sidettimgName01 = "";
$sidettimgName02 = "";
$sidettimgName03 = "";
$listimgName01 = "";
$listimgName02 = "";

switch($sidettimg){
	case 'stone': 
		$sidettimgName01 = "selected='selected'";
		break;
	case 'gbl': 
		$sidettimgName02 = "selected='selected'";
		break;
	case 'lr': 
		$sidettimgName03 = "selected='selected'";
		break;
}
switch($listimg){
	case 'blogimg':
		$listimgName01 = "selected='selected'";
		break;
	case 'blogimg2':
		$listimgName02 = "selected='selected'";
		break;
}

require $blogpath . 'zb_system/admin/admin_header.php';
require $blogpath . 'zb_system/admin/admin_top.php';
?>
<style>
	.f-table{}
	.f-table tr{}
	.f-table tr td{
		padding: 10px;
	}
	.f-text-ti{
		font-size: 12px;
		line-height: 24px;
		color: #000;
	}
	.f-ipt{
		width: 90%;
		height: 20px;
		line-height: 20px;
		padding: 4px;
	}
	.f-sel{
		height: 40px;
	}
	.f-textarea{
		height: 150px;
	}
	.f-img{
		width: 190px;
	}
	.f-img-w{
		width: 120px;
	}
</style>
<div id="divMain">
  <div class="divHeader"><?php echo $blogtitle;?></div>
  <div class="SubMenu">
  	<?php Fish_HearthStone_SubMenu($act);?>
  </div>
  <div id="divMain2">
  	<?php if ($act == 'config'){?>
    <form id="form-postdata" name="form-postdata" method="post" enctype="multipart/form-data" action="save.php?type=side">
      <table width="100%" border="1" width="80%" class="tableBorder f-table">
	      <tr>
	        <th scope="col" height="32" width="150px">配置项</th>
	        <th scope="col">配置内容</th>
	      </tr>
	      <tr>
	      	<td scope="row">右侧标题</td>
	      	<td><input class="f-ipt" name="sidett" type="text" id="textfield" value="<?php echo $sidett ?>"></td>
	      </tr>
	      <tr>
	      	<td scope="row">右侧内容</td>
	      	<td>
	      		<textarea class="f-ipt f-textarea" name="sidecon"><?php echo $sidecon ?></textarea>
	      		<p class="f-text-ti">请在70字以内</p>	
	      	</td>
	      </tr>
	      <tr>
	      	<td scope="row">右侧链接标题</td>
	      	<td><input class="f-ipt" name="sidelinktt" type="text" id="textfield" value="<?php echo $sidelinktt ?>"></td>
	      </tr>
	      <tr>
	      	<td scope="row">右侧链接</td>
	      	<td><input class="f-ipt" name="sidelink" type="text" id="textfield" value="<?php echo $sidelink ?>"></td>
	      </tr>
	      <tr>
	      	<td scope="row">右侧标题图片</td>
	      	<td>
	      		<select class="f-ipt f-sel" name="sidettimg" id="select">
				  <option value="stone" <?php echo $sidettimgName01 ?> >炉石LOGO</option>
				  <option value="gbl" <?php echo $sidettimgName02 ?> >哥布林</option>
				  <option value="lr" <?php echo $sidettimgName03 ?> >狼人</option>
				</select>	
	      	</td>
	      </tr>
	      <tr>
	      	<td scope="row">博文列表左侧图片</td>
	      	<td>
	      		<select class="f-ipt f-sel" name="listimg" id="select">
				  <option value="blogimg" <?php echo $listimgName01 ?> >拉伸美观款</option>
				  <option value="blogimg2" <?php echo $listimgName02 ?> >简单粗暴款</option>
				</select>	
	      	</td>
	      </tr>
      </table>
      <br/>
      <input class="button" type="submit" value="提交" />
    </form>
    <?php }	?>
	
	<?php if ($act == 'banner'){?>
    <form id="form-postdata" name="form-postdata" method="post" enctype="multipart/form-data" action="save.php?type=banner">
      <table width="100%" border="1" width="80%" class="tableBorder f-table">
	      <tr>
	        <th scope="col" height="32" width="100px">序号</th>
	        <th scope="col" width="200px">图片上传</th>
	        <th scope="col" width="40%">链接地址</th>
	        <th scope="col">预览</th>
	      </tr>
	      <tr>
	      	<td scope="row">01</td>
	      	<td><input class="f-img" name="banner01" type="file"/></td>
	      	<td scope="row"><input class="f-ipt" name="bannerlink01" type="text" id="textfield" value="<?php echo $bannerlink_01 ?>"></td>
	      	<td scope="row"><img class="f-img-w" src="<?php echo $bloghost . 'zb_users/theme/' . $blogtheme . '/include/banner01.jpg';?>"></td>
	      </tr>
	      <tr>
	      	<td scope="row">02</td>
	      	<td><input class="f-img" name="banner02" type="file"/></td>
	      	<td scope="row"><input class="f-ipt" name="bannerlink02" type="text" id="textfield" value="<?php echo $bannerlink_02 ?>"></td>
	      	<td scope="row"><img class="f-img-w" src="<?php echo $bloghost . 'zb_users/theme/' . $blogtheme . '/include/banner02.jpg';?>"></td>
	      </tr>
	      <tr>
	      	<td scope="row">03</td>
	      	<td><input class="f-img" name="banner03" type="file"/></td>
	      	<td scope="row"><input class="f-ipt" name="bannerlink03" type="text" id="textfield" value="<?php echo $bannerlink_03 ?>"></td>
	      	<td scope="row"><img class="f-img-w" src="<?php echo $bloghost . 'zb_users/theme/' . $blogtheme . '/include/banner03.jpg';?>"></td>
	      </tr>
      </table>
      <p class="f-text-ti"><font color="#D25300">图片尺寸为: 640*300px ; 请尽量用.jpg格式</font></p>
      <br/>
      <input class="button" type="submit" value="提交" />
    </form>
    <?php }	?>
  </div>
</div>

<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();

?>
