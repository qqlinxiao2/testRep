<div class="comm-post" id="divCommentPost">
	<div class="comment comment-form" id="comment">
		<form id="frmSumbit" target="_self" method="post" action="{$article.CommentPostUrl}" >
			<input type="hidden" name="inpId" id="inpId" value="{$article.ID}" />
			<input type="hidden" name="inpRevID" id="inpRevID" value="0" />
			{if $user.ID>0}
				<input type="hidden" name="inpName" id="inpName" value="{$user.Name}" />
				<input type="hidden" name="inpEmail" id="inpEmail" value="{$user.Email}" />
				<input type="hidden" name="inpHomePage" id="inpHomePage" value="{$user.HomePage}" />
			{else}
				<input type="text" name="inpName" id="inpName" value="{$user.Name}" />
				<input type="text" name="inpEmail" id="inpEmail" value="{$user.Email}" />
				<input type="text" name="inpHomePage" id="inpHomePage" value="{$user.HomePage}" />
			{/if}
			<div class="text">
				<textarea type="text" name="txaArticle" id="txaArticle" class="textarea" ></textarea>
			</div>
			<div class="code">
				{if $option['ZC_COMMENT_VERIFY_ENABLE']}
					<input type="text" class="ipt" name="inpVerify" id="inpVerify"  value="" />
					
					<img style="width:{$option['ZC_VERIFYCODE_WIDTH']}px;height:{$option['ZC_VERIFYCODE_HEIGHT']}px;cursor:pointer;" src="{$article.ValidCodeUrl}" alt="" title="" onclick="javascript:this.src='{$article.ValidCodeUrl}&amp;tm='+Math.random();"/>
				{/if}
			</div>
			<div class="menu">
				<input name="sumbit" type="submit" tabindex="6" onclick="return VerifyMessage()" value="发表评论" class="post-submit"/>
			</div>
		</form>
	</div>
</div>