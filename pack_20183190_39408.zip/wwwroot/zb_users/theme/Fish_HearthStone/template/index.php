
	{template:header}
						{php}
							$sidett = $zbp->Config('Fish_HearthStone') -> side_tt;
							$sidecon = $zbp->Config('Fish_HearthStone') -> side_con;
							$sidelinktt = $zbp->Config('Fish_HearthStone') -> side_linktt;
							$sidelink = $zbp->Config('Fish_HearthStone') -> side_link;
							$sidettimg = $zbp->Config('Fish_HearthStone') -> side_tt_img;
							$bannerlink01 = $zbp->Config('Fish_HearthStone') -> banner_link_01;
							$bannerlink02 = $zbp->Config('Fish_HearthStone') -> banner_link_02;
							$bannerlink03 = $zbp->Config('Fish_HearthStone') -> banner_link_03;
						{/php}
						<div class="g-con">
							<div class="g-left">
								<div class="m-con">
									<div class="top-shadow"></div>
									<div class="foot-bg"></div>
									<div class="m-list">
										<div class="m-banner">
											<ul>
												<li><a href="{$bannerlink01}" target="_blank"><img src="{$host}zb_users/theme/{$theme}/include/banner01.jpg" /></a></li>
												<li><a href="{$bannerlink02}" target="_blank"><img src="{$host}zb_users/theme/{$theme}/include/banner02.jpg" /></a></li>
												<li><a href="{$bannerlink03}" target="_blank"><img src="{$host}zb_users/theme/{$theme}/include/banner03.jpg" /></a></li>
											</ul>
											
										</div><!-- ./m-banner -->
										
										{foreach $articles as $article}
											{if $article.IsTop}
											
												{template:post-istop}
												
											{/if}
										{/foreach}
										
										<div class="m-top-line"></div>
										
										{foreach $articles as $article}
											{if $article.IsTop}
											{else}
												
												{template:post-multi}
												
											{/if}
											
										{/foreach}
										
										<div class="m-page">
											{template:pagebar}
											
										</div><!-- ./m-page -->
									</div><!-- ./m-list -->
								</div><!-- ./m-con -->
							</div><!-- ./g-left -->
							<div class="g-right">
								<div class="m-side">
									<div class="m-side-top">
										<div class="decorate-{$sidettimg}"></div>
										<div class="decorate-loe-icon"></div>
										<div class="m-side-about">
											<h4>{$sidett}</h4>
											<div class="about-con">
												{$sidecon}
											</div>
											<a href="{$sidelink}" class="about-menu" target="_blank">{$sidelinktt}</a>
										</div>
									</div><!-- ./m-side-top-->
									
									{template:c_right}
									
									<div class="m-list-foot"></div>
								</div>
							</div><!-- ./g-right -->
							<div class="clear"></div>
						</div><!-- ./g-con -->
					
			{template:footer}
			
		
		
		