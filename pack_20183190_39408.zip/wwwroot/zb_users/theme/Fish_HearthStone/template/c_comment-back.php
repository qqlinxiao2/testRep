<div class="comm-list">
	<ul>
		<li>
			<a href="#comment" class="list-back" onclick="RevertComment('{$comment.ID}')">回复该评论</a>
			<div class="list-sub">
				<a href="{$comment.Author.HomePage}" class="name">{$comment.Author.StaticName}</a>
				<span class="data">{$comment.Time()}</span>
			</div>
			<div class="list-con">
				{$comment.Content}
			</div>
		</li>
		{foreach $comment.Comments as $comment}
			{template:c_comment-back}
		{/foreach}
	</ul>
</div>