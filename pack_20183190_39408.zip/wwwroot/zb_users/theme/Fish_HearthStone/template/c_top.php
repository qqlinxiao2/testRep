<div class="g-head">
							<div class="m-logo">
								<h1>{$name}</h1>
								<div class="logo-text">{$subname}</div>
							</div>
							<div class="m-search">
								<form action="{$host}zb_system/cmd.php?act=search" method="post" name="search">
									<input type="text" name="q" class="ipt" placeholder="输入关键字" maxlength="50" value=""></input>
									<input type="submit" class="btn" value="" ></input>
								</form>
							</div>
						</div><!-- ./g-head -->
						<div class="g-nav">
							<span class="left-icon"></span>
							<span class="right-icon"></span>
							<ul class="m-nav">
								{module:navbar}
								
							</ul>
						</div><!-- ./g-nav -->