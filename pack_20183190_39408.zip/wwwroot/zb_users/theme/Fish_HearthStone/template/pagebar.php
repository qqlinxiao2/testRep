<ul class="page-menu">
	{if $pagebar}
		{foreach $pagebar.buttons as $k=>$v}
		    {if $pagebar.PageNow==$k}
		    <li><span class="page-now"></span><a>　</a></li>
		    {elseif $k=='‹‹'}
		    <a href="{$v}" class="page-left">　</a>
		    {elseif $k=='››'}
		    <a href="{$v}" class="page-right">　</a>
		    {elseif $k=='‹'}
		    
		    {elseif $k=='›'}
		    
		    {else}
		    <li><a href="{$v}">{$k}</a></li>
		    {/if}
		{/foreach}
	{/if}
</ul>