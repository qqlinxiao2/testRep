</div><!-- ./g-main -->
				</div>
			</div>
<div class="g-foot">
				<div class="m-foot">
					{$copyright}
				</div>
			</div>
			</div>
			{$footer}
	</body>
</html>