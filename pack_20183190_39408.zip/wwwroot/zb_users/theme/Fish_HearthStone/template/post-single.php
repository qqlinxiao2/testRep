<div class="m-blog-con">
	<h2 class="blog-tt">{$article.Title}</h2>
	<div class="blog-sub">
		<span class="name">作者：{$article.Author.Name}</span>
		<span class="time">{$article.Time('Y-m-d H:i:s')}</span>
		<span class="reply">{$article.CommNums}</span>
		<span class="tag">标签：
			{foreach $article.Tags as $tag}<a href="{$tag.Url}">{$tag.Name}</a>{/foreach}
		</span>
	</div>
	<div class="blogCon">
		{$article.Content}
		
	</div>
</div>
<div class="m-blog-next">
	<div class="left">上一篇：<a href="{$article.Prev.Url}">{$article.Prev.Title}</a></div>
	<div class="right">下一篇：<a href="{$article.Next.Url}">{$article.Next.Title}</a></div>
</div>
<div class="m-blog-line"></div>
{if !$article.IsLock}
	{template:comments}
{/if}
