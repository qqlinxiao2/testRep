<div class="m-blog-con">
	<h2 class="blog-tt">{$article.Title}</h2>
	<div class="blog-sub">
		<span class="name">作者：{$article.Author.Name}</span>
		<span class="time">{$article.Time('Y-m-d H:i:s')}</span>
		<span class="reply">{$article.CommNums}</span>
	</div>
	<div class="blogCon">
		{$article.Content}
		
	</div>
</div>
<div class="m-blog-line"></div>
{if !$article.IsLock}
	{template:comments}
{/if}
