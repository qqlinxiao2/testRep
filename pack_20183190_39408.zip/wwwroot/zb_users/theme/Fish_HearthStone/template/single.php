
	{template:header}
						
						<div class="g-con">
							<div class="m-con-widh">
								{if $article.Type==ZC_POST_TYPE_ARTICLE}
									{template:post-single}
								{else}
									{template:post-page}
								{/if}
								
							</div>
							<div class="m-con-widh-foot"></div>
						</div><!-- ./g-con -->
					
			{template:footer}
			
		
		
		