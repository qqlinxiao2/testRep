{template:header}
{if $DFiveAD1ON}<div class="banner">{$DFiveAD1}</div>{/if}
{if $DFiveTipsON}<div class="thetip">{$DFiveTips}</div>{/if}
<div class="share-txt share-home">我喜欢，分享到：<a class="dshare ds_tqq">腾讯微博</a><a class="dshare ds_qzone">QQ空间</a><a class="dshare ds_tsina">新浪微博</a><a class="dshare ds_renren">人人网</a><a class="dshare ds_kaixin">开心网</a><a class="dshare ds_douban">豆瓣</a><a class="dshare ds_facebook">Facebook</a><a class="dshare ds_twitter">Twitter</a></div>
{if $type!='index'}
<h2 class="base-tit queryinfo">{$title}的内容</h2>
{/if}
<ul class="excerpt{if $DFiveThumb} thumb{/if}">
{foreach $articles as $article}
    {if $article.IsTop}
    	{template:post-istop}
    {else}
    	{if $DFiveThumb}
        	{template:post-thumb}
        {else}
    		{template:post-multi}
        {/if}
    {/if}
{/foreach}
</ul>
<div class="paging">{template:pagebar}</div>
</div>
{template:post-sidebar}
{template:footer}