<div class="meta">
  <h1 class="meta-tit">{$article.Title}<span><a href="#respond" title="《{$article.Title}》上的评论">{$article.CommNums}条评论</a></span></h1>
  <div class="share-ico">分享到：<a class="dshare ds_tqq">腾讯微博</a><a class="dshare ds_qzone">QQ空间</a><a class="dshare ds_tsina">新浪微博</a><a class="dshare ds_renren">人人网</a><a class="dshare ds_kaixin">开心网</a><a class="dshare ds_douban">豆瓣</a><a class="dshare ds_facebook">Facebook</a><a class="dshare ds_twitter">Twitter</a></div>
  <p class="meta-info">{$article.Time('Y年m月d日')}&nbsp;&nbsp; 分类：<a href="{$article.Category.Url}">{$article.Category.Name}</a>&nbsp;&nbsp; {$article.ViewNums}人浏览
  </p>
</div>
{if $DFiveAD2ON}<div class="banner">{$DFiveAD2}</div>{/if}
<div class="entry"> {$article.Content} <p>转载请注明：<a href="{$host}">{$name}</a> &raquo; <a href="{$article.Url}">{$article.Title}</a></p></div>
{if $article.Tags}<div class="excerpt-tag"> 继续查看有关 {foreach $article.Tags as $tag}<a href="{$tag.Url}">{$tag.Name}</a>{/foreach} 的文章 </div>{/if}
<div class="share-txt">分享到：<a class="dshare ds_tqq">腾讯微博</a><a class="dshare ds_qzone">QQ空间</a><a class="dshare ds_tsina">新浪微博</a><a class="dshare ds_renren">人人网</a><a class="dshare ds_kaixin">开心网</a><a class="dshare ds_douban">豆瓣</a><a class="dshare ds_facebook">Facebook</a><a class="dshare ds_twitter">Twitter</a></div>
{if $DFiveAD3ON}<div class="banner">{$DFiveAD3}</div>{/if}
{$array=GetList(5,null,null,null,null,null,array('is_related'=>$article->ID));}
{if $array}
<h3 class="base-tit">相关文章</h3>
<ul class="post-related">
{foreach $array as $related}
    <li><a href='{$related.Url}' target="_blank">{$related.Title}</a>&nbsp;<strong>{$article.CommNums}条评论</strong> &nbsp;&nbsp; {$article.ViewNums}次浏览 &nbsp;&nbsp; {$article.Time('Y年m月d日')} </li>
{/foreach}
</ul>
{/if}
{if !$article.IsLock}
{template:comments}
{/if} 