<li class="comment byuser comment-author-admin bypostauthor even thread-even depth-1" id="comment-{$comment.ID}">
  <div class="c-floor"><a href="#comment-{$comment.ID}">#{$comment.FloorID}</a></div>
  <div class="c-avatar"><img src="{$comment.Author.Avatar}" class="avatar" /></div>
  <div class="c-main" id="div-comment-{$comment.ID}">
    <p>{$comment.Content}</p>
    <div class="c-meta"><span class="c-author"><a href="{$comment.Author.HomePage}" target="_blank" rel="external nofollow" class="url">{$comment.Author.StaticName}</a></span>{$comment.Time()}<a href="#respond"  class='comment-reply-link' onclick="RevertComment('{$comment.ID}')">回复该评论</a></div>
  </div>
</li>
{foreach $comment.Comments as $comment}
<div style="padding-left:20px">{template:comment}</div>
{/foreach}