<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width" />
<title>{if $type=='index'}{$name}_{$title}
{elseif $type=='category'}{$title}_{$name}
{elseif $type=='article'}{$title}_{$article.Category.Name}_{$name}
{else}{$title}_{$name}{/if}</title>
{$header}
<meta name="generator" content="{$zblogphp}" />
<link rel="stylesheet" rev="stylesheet" href="{$host}zb_users/theme/{$theme}/style/{$style}.css" type="text/css" media="all"/>
<script src="{$host}zb_system/script/common.js" type="text/javascript"></script>
<script src="{$host}zb_system/script/c_html_js_add.php" type="text/javascript"></script>
<script src="{$host}zb_users/theme/{$theme}/script/common.js"></script>
{$header}
{if $type=='index'&&$page=='1'}
	<link rel="alternate" type="application/rss+xml" href="{$feedurl}" title="{$name}" />
	<link rel="EditURI" type="application/rsd+xml" title="RSD" href="{$host}zb_system/xml-rpc/?rsd" />
	<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="{$host}zb_system/xml-rpc/wlwmanifest.xml" />
{/if}
</head>
<body class="multi {$type}">
<div class="topbar">
	<div class="inner">
		<h1 class="logo"><a class="logo" href="{$host}" title="{$name} - {$subname}">{$subname}</a></h1>
		<ul class="nav">
			{module:navbar}
		</ul>
		<form name="search" method="post" action="{$host}zb_system/cmd.php?act=search" class="search-form">
			<input type="text" x-webkit-speech onfocus="if (this.value == '回车搜索 直接有效') {this.value = '';}" onblur="if (this.value == '') {this.value = '回车搜索 直接有效';}" value="回车搜索 直接有效" name="q" class="search-input" />
		</form>
		<ul class="nav topmenu">
			{module:favorite}
		</ul>
	</div>
</div>
<div class="wrapper">
	<div class="content">