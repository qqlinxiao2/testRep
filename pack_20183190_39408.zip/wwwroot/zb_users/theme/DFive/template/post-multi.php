<li>
  <div class="excerpt-num">
  	<span class="num-comm num-comm-hot"><strong>{$article.CommNums}</strong>answers</span> 
    <span class="num-view"><strong>{$article.ViewNums}</strong>views</span> 
  </div>
  <h2 class="excerpt-tit"> <a href="{$article.Url}">{$article.Title}</a> </h2>
  <p class="excerpt-desc"> {php}$intro= preg_replace('/[\r\n\s]+/', '', trim(SubStrUTF8(TransferHTML($article->Intro,'[nohtml]'),80)).'...');{/php}{$intro} </p>
  <div class="excerpt-tag"> {foreach $article.Tags as $tag}<a href="{$tag.Url}">{$tag.Name}</a>{/foreach} </div>
  <div class="excerpt-time">{$article.Time('Y年m月d日')}</div>
</li>