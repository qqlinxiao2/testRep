<div class="sidebar">
	<ul class="mypages">
		<li><a target="_blank" class="my-a my-tqq" href="http://<?php echo dopt('d_tqq'); ?>"><span><strong>腾讯微博</strong></span>腾讯微博 &raquo;</a></li>
		<li><a target="_blank" class="my-a my-weibo" href="http://<?php echo dopt('d_weibo'); ?>"><span><strong>新浪微博</strong></span>新浪微博 &raquo;</a></li>
	</ul>
    {template:sidebar}
</div>