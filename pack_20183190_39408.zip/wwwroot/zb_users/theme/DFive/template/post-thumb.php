<li> <a href="{$article.Url}" class="pic"><img src="{DFive_thumbs($article.Content)}" alt="{$article.Title}" /></a>
  <h2 class="excerpt-tit"> <a href="{$article.Url}">{$article.Title}</a> </h2>
  <p class="excerpt-desc"> {php}$intro= preg_replace('/[\r\n\s]+/', '', trim(SubStrUTF8(TransferHTML($article->Intro,'[nohtml]'),80)).'...');{/php}{$intro} </p>
  <div class="excerpt-tag"> {foreach $article.Tags as $tag}<a href="{$tag.Url}">{$tag.Name}</a>{/foreach} <span>{$article.CommNums}评论 &nbsp; {$article.ViewNums}次访问</span> </div>
  <div class="excerpt-time">{$article.Time('Y年m月d日')}</div>
</li>