</div>
<div class="footer">
	<div class="inner">
		<p class="manage">Theme By <a href="http://www.huisem.com" target="_blank">流年博客</a></p>
		<p class="copyright">
            {$copyright} Powered By {$zblogphphtml} Design By <a href="http://www.daqianduan.com" target="_blank">大前端</a> 
		</p>
	</div>
</div>
{$footer}
</body>
</html>