{if $socialcomment}
{$socialcomment}
{else}
<div id="postcomments">
{if $article.CommNums>0}
<h3 class="base-tit" id="comments"> <span><a href="#"></a></span><strong>{$article.CommNums}</strong>访客评论，博主回复<strong>4</strong>条 </h3>
{/if}
<label id="AjaxCommentBegin"></label>
<!--评论输出-->
<ol class="commentlist">
{foreach $comments as $key => $comment}
{template:comment}
{/foreach}
</ol>
<!--评论翻页条输出-->
<div class="pagenav pagebar commentpagebar">
{template:pagebar}
</div>
<label id="AjaxCommentEnd"></label>
</div>
<!--评论框-->
{template:commentpost}
{/if}