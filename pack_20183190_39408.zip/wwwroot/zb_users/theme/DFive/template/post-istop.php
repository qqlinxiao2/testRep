<li style="padding-left:0;">
  <h2 class="excerpt-tit"> <a href="{$article.Url}">[置顶]{$article.Title}</a> </h2>
  <p class="excerpt-desc"> {php}$intro= preg_replace('/[\r\n\s]+/', '', trim(SubStrUTF8(TransferHTML($article->Intro,'[nohtml]'),80)).'...');{/php}{$intro} </p>
  <div class="excerpt-time">{$article.Time('Y年m月d日')}</div>
</li>