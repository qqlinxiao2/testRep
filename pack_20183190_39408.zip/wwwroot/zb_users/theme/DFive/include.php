<?php
//注册插件
define('TEMPLATE_DFive_IS_WINDOWS', (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN'));
RegisterPlugin('DFive', 'ActivePlugin_DFive');

function ActivePlugin_DFive()
{
	Add_Filter_Plugin('Filter_Plugin_Admin_TopMenu','DFive_AddMenu');//顶部主题配置按钮
	Add_Filter_Plugin('Filter_Plugin_ViewList_Template','DFive_tags_set');//标签设置
	Add_Filter_Plugin('Filter_Plugin_ViewPost_Template','DFive_tags_set');//标签设置
}
//后台按钮
function DFive_AddMenu(&$m){
	global $zbp;
	array_unshift($m, MakeTopMenu("root",'主题配置',$zbp->host . "zb_users/theme/DFive/plugin/main.php","","topmenu_show"));

}

function DFive_SubMenu($id){
	$aryCSubMenu = array(
		0 => array('首页', 'main.php', 'left', false),
		1 => array('基本设置', 'config.php', 'left', false),
		2 => array('广告系统', 'ad.php', 'left', false),
		3 => array('<b style="color:red;">作者</b>', 'http://www.huisem.com', 'right', true)
	);
	foreach($aryCSubMenu as $k => $v){
		echo '<a href="'.$v[1].'" '.($v[3]==true?'target="_blank" style="float:right"':'').' class="'.($id==$k?'d_tab_on':'').'">'.$v[0].'</a>';
	}
}

function DFive_tags_set(&$template){
	global $zbp,$blogversion;
	if($blogversion>=150101){
		$array = $zbp->configs['DFive']->GetData();
	}else{
		$array = $zbp->configs['DFive']->Data;
	}
	foreach ($array as $key=>$val){
			$template->SetTags($key,$val);
	}
	if ($zbp->Config('DFive')->DFiveKeys){
		$zbp->header .= "<meta name=\"keywords\" content=\"".$zbp->Config('DFive')->DFiveKeys."\" />\r\n";
	}
	if ($zbp->Config('DFive')->DFiveDesc){
		$zbp->header .= "<meta name=\"description\" content=\"".$zbp->Config('DFive')->DFiveDesc."\" />\r\n";
	}
	if ($zbp->Config('DFive')->DFiveCountON){
		$zbp->footer .= $zbp->Config('DFive')->DFiveCount."\r\n";
	}
	
}

//初始安装
function InstallPlugin_DFive()
{
	global $zbp;
	if(!$zbp->Config('DFive')->HasKey('Version')){
		$zbp->Config('DFive')->Version = '1.1';
		
		$zbp->Config('DFive')->DFiveTips='友情提示：本站升级维护中，如给您带来不便，还望谅解！';
		$zbp->Config('DFive')->DFiveKeys='zblog,zblogphp';
		$zbp->Config('DFive')->DFiveDesc='恒辉工作室（www.huisem.com），专注zblog模板设计制作！';
		$zbp->Config('DFive')->DFiveWeibo='http://t.qq.com/q841217204';
		$zbp->Config('DFive')->DFiveSina='http://t.qq.com/q841217204';
		$zbp->Config('DFive')->DFiveCount='百度统计、CNZZ、51啦、量子统计等等';
		
		$zbp->Config('DFive')->DFiveTipsON=1;
		$zbp->Config('DFive')->DFiveAD1ON=$zbp->Config('DFive')->DFiveAD2ON=$zbp->Config('DFive')->DFiveAD3ON=$zbp->Config('DFive')->DFiveThumb=$zbp->Config('DFive')->DFiveCountON=$zbp->Config('DFive')->DFiveClearON=0;
		
		$zbp->SaveConfig('DFive');
	}
	$zbp->Config('DFive')->Version = '1.1';
	$zbp->SaveConfig('DFive');
}
//卸载主题
function UninstallPlugin_DFive()
{
	global $zbp;
	if ($zbp->Config('DFive')->DFiveClearON){
		$zbp->DelConfig('DFive');
	}
}
function DFive_thumbs($as) {
    global $zbp;
    $SiteSRC = '';
    $pattern="/<[img|IMG].*?src=[\'|\"](.*?(?:[\.gif|\.jpg|\.png]))[\'|\"].*?[\/]?>/";
    preg_match_all($pattern,$as,$matchContent);
    if  (isset($matchContent[1][0])) {
        $SiteSRC=$matchContent[1][0];
    } else {
        $SiteSRC= $zbp->host . "zb_users/theme/DFive/style/img/thumbnail.png";
    }
    return $SiteSRC;
}
?>