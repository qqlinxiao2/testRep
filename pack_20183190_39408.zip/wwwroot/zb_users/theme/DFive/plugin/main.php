<?php
require '../../../../zb_system/function/c_system_base.php';
require '../../../../zb_system/function/c_system_admin.php';

$zbp->Load();
$action='root';
if (!$zbp->CheckRights($action)) {$zbp->ShowError(6);die();}
if (!$zbp->CheckPlugin('DFive')) {$zbp->ShowError(48);die();}
$blogtitle=$zbp->theme.'主题配置->配置首页';

require $blogpath . 'zb_system/admin/admin_header.php';
require $blogpath . 'zb_system/admin/admin_top.php';
?>
<div class="wrap d_wrap">
    <link rel="stylesheet" href="dtheme.css"/>
    <div class="divHeader"><?php echo $blogtitle;?></div>
    <form method="post">
    <div class="d_tab"><?php DFive_SubMenu(0);?></div>
    <div class="d_mainbox" id="d_mainbox_1" style="padding-bottom:0;">
        <div class="d_desc">温馨提示：</div>
        <table width="100%" style='margin:0; padding:0;margin-top:36px;' cellspacing='0' cellpadding='0' class="tableBorder">
        <tr height="32"><td style="color:#F00">        1、本页面是主题插件设置页面，请谨慎操作；</td></tr>
        <tr height="32"><td>       2、配置不当可能会造成网站内容的错位；</td></tr>
        <tr height="32"><td>       3、如有宝贵意见还望提出，将在下一版中进行修订；</td></tr>
        <tr height="32"><td>       </td></tr>
        <tr height="32"><td>       </td></tr>
        <tr height="32"><td>       </td></tr>
        <tr height="32"><td>       主题作者：流年。主页：<a href="http://www.huisem.com" target="_blank" style="color:#F00">流年博客</a></td></tr>
        <tr height="32"><td>       如果在使用过程中有什么问题，请到作者主页进行反馈。</td></tr>
        </tr>
        </table>
    </div>
    </form>
</div>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
?>