<?php
require '../../../../zb_system/function/c_system_base.php';
require '../../../../zb_system/function/c_system_admin.php';

$zbp->Load();
$action='root';
if (!$zbp->CheckRights($action)) {$zbp->ShowError(6);die();}
if (!$zbp->CheckPlugin('DFive')) {$zbp->ShowError(48);die();}
$blogtitle=$zbp->theme.'主题配置->基本设置';

require $blogpath . 'zb_system/admin/admin_header.php';
require $blogpath . 'zb_system/admin/admin_top.php';

if(isset($_POST['Forum'])){
	foreach($_POST['Forum'] as $key=>$val){
	   $zbp->Config('DFive')->$key = $val;
	}
	$zbp->SaveConfig('DFive');
	$zbp->ShowHint('good');
}
?>
<?php
foreach ($GLOBALS['Filter_Plugin_Edit_Begin'] as $fpname => &$fpsignal) {$fpname();}
?>

<div class="wrap d_wrap">
  <link rel="stylesheet" href="dtheme.css"/>
  <div class="divHeader"><?php echo $blogtitle;?></div>
  <form method="post">
    <div class="d_tab"><?php DFive_SubMenu(1);?></div>
    <div class="d_mainbox" id="d_mainbox_1">
      <div class="d_desc">
        <input class="button-primary" name="save1" type="submit" value="保存设置" />
        主题的基本设置，包括模块是否开启等</div>
      <ul class="d_inner">
        <li class="d_li"> </li>
        <li class="d_li">
          <h4>升级/维护提醒：</h4>
          <label class="d_check" for="DFiveTipsON">
            <input type="text" id="DFiveTipsON" name="Forum[DFiveTipsON]" class="checkbox" value="<?php echo $zbp->Config('DFive')->DFiveTipsON;?>"  /></label>
          <input class="d_inp " name="Forum[DFiveTips]" id="DFiveTips" type="text" value="<?php echo $zbp->Config('DFive')->DFiveTips;?>" />
        </li>
        <li class="d_li">
          <h4>网站关键字：</h4>
          <input class="d_inp " name="Forum[DFiveKeys]" id="DFiveKeys" type="text" value="<?php echo $zbp->Config('DFive')->DFiveKeys;?>" />
        </li>
        <li class="d_li">
          <h4>网站描述：</h4>
          <input class="d_inp " name="Forum[DFiveDesc]" id="DFiveDesc" type="text" value="<?php echo $zbp->Config('DFive')->DFiveDesc;?>" />
        </li>
        <li class="d_li">
          <h4>腾讯微博：</h4>
          <input class="d_inp d_inp_short" name="Forum[DFiveWeibo]" id="DFiveWeibo" type="text" value="<?php echo $zbp->Config('DFive')->DFiveWeibo;?>" />
        </li>
        <li class="d_li">
          <h4>新浪微博：</h4>
          <input class="d_inp d_inp_short" name="Forum[DFiveSina]" id="DFiveSina" type="text" value="<?php echo $zbp->Config('DFive')->DFiveSina;?>" />
        </li>
        <li class="d_li">
          <h4>流量统计代码：</h4>
          <label class="d_check" for="DFiveCountON"><input type="text" id="DFiveCountON" name="Forum[DFiveCountON]" class="checkbox" value="<?php echo $zbp->Config('DFive')->DFiveCountON;?>"  /></label>
          <textarea class="d_tarea" name="Forum[DFiveCount]" id="DFiveCount" type="textarea" cols="" rows=""><?php echo htmlspecialchars($zbp->Config('DFive')->DFiveCount);?></textarea>
        </li>
        <li class="d_li">
          <h4>文章缩略图：</h4>
          <label class="d_check" for="DFiveThumb"><input type="text" id="DFiveThumb" name="Forum[DFiveThumb]" class="checkbox" value="<?php echo $zbp->Config('DFive')->DFiveThumb;?>"  /></label>
        </li>
        <li class="d_li">
          <h4>切换主题清除配置：</h4>
          <label class="d_check" for="DFiveClearON"><input type="text" id="DFiveClearON" name="Forum[DFiveClearON]" class="checkbox" value="<?php echo $zbp->Config('DFive')->DFiveClearON;?>"  /></label>
        </li>
      </ul>
      <div class="d_desc d_desc_b">
        <input class="button-primary" name="save1" type="submit" value="保存设置" />
      </div>
    </div>
  </form>
</div>
<?php
if ($zbp->CheckPlugin('UEditor')) {
	echo "<script type=\"text/javascript\" src=\"lib.upload.js\"></script>";
}
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
?>
