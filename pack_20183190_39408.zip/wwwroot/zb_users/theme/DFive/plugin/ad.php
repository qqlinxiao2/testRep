<?php
require '../../../../zb_system/function/c_system_base.php';
require '../../../../zb_system/function/c_system_admin.php';

$zbp->Load();
$action='root';
if (!$zbp->CheckRights($action)) {$zbp->ShowError(6);die();}
if (!$zbp->CheckPlugin('DFive')) {$zbp->ShowError(48);die();}
$blogtitle=$zbp->theme.'主题配置->广告设置';

require $blogpath . 'zb_system/admin/admin_header.php';
require $blogpath . 'zb_system/admin/admin_top.php';

if(isset($_POST['Forum'])){
	foreach($_POST['Forum'] as $key=>$val){
	   $zbp->Config('DFive')->$key = $val;
	}
	$zbp->SaveConfig('DFive');
	$zbp->ShowHint('good');
}
?>
<?php
foreach ($GLOBALS['Filter_Plugin_Edit_Begin'] as $fpname => &$fpsignal) {$fpname();}
?>

<div class="wrap d_wrap">
  <link rel="stylesheet" href="dtheme.css"/>
  <div class="divHeader"><?php echo $blogtitle;?></div>
  <form id="form1" name="form1" method="post">
    <div class="d_tab"><?php DFive_SubMenu(2);?></div>
    <div class="d_mainbox">
      <div class="d_desc"><input class="button-primary" name="save2" type="submit" value="保存设置" /> 站点的广告展示，包括图片广告、Google广告、百度联盟、淘宝联盟等，将代码贴入即可</div>
      <ul class="d_inner">
        <li class="d_li"> </li>
        <li class="d_li">
          <h4>全站-内容上：</h4>
          <label class="d_check" for="DFiveAD1ON">
            <input type="text" id="DFiveAD1ON" name="Forum[DFiveAD1ON]" class="checkbox" value="<?php echo $zbp->Config('DFive')->DFiveAD1ON;?>" /></label>
          <textarea class="d_tarea" name="Forum[DFiveAD1]" id="DFiveAD1" type="textarea" cols="" rows=""><?php echo htmlspecialchars($zbp->Config('DFive')->DFiveAD1);?></textarea>
        </li>
        <li class="d_li">
          <h4>文章页-正文上：</h4>
          <label class="d_check" for="DFiveAD2ON">
            <input type="text" id="DFiveAD2ON" name="Forum[DFiveAD2ON]" class="checkbox" value="<?php echo $zbp->Config('DFive')->DFiveAD2ON;?>" /></label>
          <textarea class="d_tarea" name="Forum[DFiveAD2]" id="DFiveAD2" type="textarea" cols="" rows=""><?php echo htmlspecialchars($zbp->Config('DFive')->DFiveAD2);?></textarea>
        </li>
        <li class="d_li">
          <h4>文章页-正文下：</h4>
          <label class="d_check" for="DFiveAD3ON">
            <input type="text" id="DFiveAD3ON" name="Forum[DFiveAD3ON]" class="checkbox" value="<?php echo $zbp->Config('DFive')->DFiveAD3ON;?>" /></label>
          <textarea class="d_tarea" name="Forum[DFiveAD3]" id="DFiveAD3" type="textarea" cols="" rows=""><?php echo htmlspecialchars($zbp->Config('DFive')->DFiveAD3);?></textarea>
        </li>
      </ul>
      <div class="d_desc d_desc_b">
        <input class="button-primary" name="save2" type="submit" value="保存设置" />
      </div>
    </div>
  </form>
  <script type="text/javascript">
	$(function(){
	//广告系统实时预览
	$('.d_mainbox:last .d_tarea').each(function(i) {
		$(this).bind('keyup',function(){
			$(this).next().html( $(this).val() );
		}).bind('change',function(){
			$(this).next().html( $(this).val() );
		}).bind('click',function(){
			$(this).next().html( $(this).val() );
			if( $(this).next().attr('class') != 'd_adviewcon' ){
				$(this).after('<div class="d_adviewcon">' + $(this).val() + '</div>');
			}else{
				$(this).next().slideDown();
			}
		})
	});
	})
  </script> 
</div>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
?>
